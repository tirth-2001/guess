Guess
A Python package to get random number between 10 to 20.

Usage
This will generate a random number between 10 to 20.