# -*- coding: utf-8 -*-
"""
Created on Thu Nov  7 09:25:39 2019

@author: user
"""

import random

def guess():
    a= random.randint(10,20)
    return a

print("Random Number is : ",guess())
